$(function() {
    $("#send").click(updateGuests);
});

function updateGuests() {
    var first = $("#first").val();
    var last = $("#last").val();
    
    $.ajax("guest.ajax", {
		"type": "post",
		"data": {
        	"first": first,
            "last": last
		}
    }).done(displayGuests).fail(failFunction);
}

function displayGuests(data) {
    $("#guestList").empty();
    let ul= $('<ul>');
    try {
        $.each(data, function(indx, elem){
            let listItem= $('<li>');
            listItem.text(elem.first + " " + elem.last );
            ul.append(listItem);
        });
    }catch(e) {
        $("#guestList").empty();
    }
    $("#guestList").append(ul);
}
function failFunction(xhr, status, exception) {
    alert("failed is the ajax.");
    console.log(xhr, status, exception);
}