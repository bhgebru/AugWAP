package cs472.mum;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "CalculatorServlet")
public class CalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String o="";
        if(request.getParameter("num1")!=null)
        {
            if(request.getParameter("num2")!=null)
            {
                int num1= Integer.parseInt(request.getParameter("num1"));
                int num2= Integer.parseInt(request.getParameter("num2"));
                o= o + "\n" + num1 + " + " + num2 + " = " + (num1+num2) + "\n";
            }
        }
        if(request.getParameter("num1")!=null)
        {
            if(request.getParameter("num2")!=null)
            {
                int num3= Integer.parseInt(request.getParameter("num3"));
                int num4= Integer.parseInt(request.getParameter("num4"));
                o= o + "\n" + num3 + " x " + num4 + " = " + (num3*num4) + "\n";
            }
        }
        response.getWriter().println(o);
        //request.getRequestDispatcher('/index.jsp').forward();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
