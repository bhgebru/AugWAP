/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;

import app.Quiz;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;


/**
 * @author levi
 */

public class Lab03Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        HttpSession sess = request.getSession();
        Quiz sessQuiz = (Quiz) sess.getAttribute("quiz");
        /* REFACTORed -- now checks for null sessQuiz */
        if (sessQuiz == null) {
            sessQuiz = new Quiz();
            sess.setAttribute("quiz", sessQuiz);
        }
        /* now need to get an input from the user and process it */
        String answer = request.getParameter("txtAnswer");
        //System.out.println("Answer is: " + answer);
        if(answer == null)
            answer="";
        request.setAttribute("answer", answer);
        boolean error = true;
        /* i.e., if answer is correct then increment the question index and score */
        if ((answer != null) && sessQuiz.isCorrect(answer)) {
            error = false;
            sessQuiz.markAnswerCorrect();
        }
        request.setAttribute("error", error);
        /* NEED TO see if are at end of quiz and go to finish page if so? 
         * refactor:  probably better if have an isFinished method in Quiz to encapsulate the logic. */
        if (sessQuiz.getTotNumQuestions() == sessQuiz.getCurrentQuestionIndex()) {
            sess.invalidate();
            request.removeAttribute("error");
            request.removeAttribute("currQuest");
            request.removeAttribute("answer");
            response.sendRedirect("quiz_over.jsp");
        } else {
            /* get a question and print it out */
            String currQuest = sessQuiz.getCurrentQuestion();
            request.setAttribute("currQuest", currQuest);
            request.getRequestDispatcher("quiz_gen.jsp").forward(request, response);
        }

    }

    /**
     * Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
