package app; /**
 * app.Question has a question and associated (correct) answer
 */

/**
 *
 * @author levi
 */
public class Question {
    private String question;
    private String answer;
    
    public Question(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }
    @Override
    public String toString() {
        return "\n\tQuestion: " + this.question + "\n\t" + this.answer;
    }
}
